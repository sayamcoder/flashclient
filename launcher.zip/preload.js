const { contextBridge, ipcRenderer } = require('electron');

function on(channel, callback) {
  const handler = (event, payload) => callback(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
}

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('window-minimize'),
  close: () => ipcRenderer.send('window-close'),
  hideToTray: () => ipcRenderer.send('window-hide'),
  showWindow: () => ipcRenderer.send('tray-show'),
  quitApp: () => ipcRenderer.invoke('app-quit'),
  trayAvailable: () => ipcRenderer.invoke('tray-available'),
  toggleMaximize: () => ipcRenderer.invoke('window-maximize'),
  isMaximized: () => ipcRenderer.invoke('window-maximized-state'),

  horizonStatus: () => ipcRenderer.invoke('horizon-status'),
  pickHorizon: () => ipcRenderer.invoke('horizon-pick'),
  pickHorizonInstaller: () => ipcRenderer.invoke('horizon-pick-installer'),
  installHorizon: (installerPath) => ipcRenderer.invoke('horizon-install', installerPath),
  launchHorizon: () => ipcRenderer.invoke('horizon-launch'),
  horizonBootstrap: () => ipcRenderer.invoke('horizon-bootstrap'),
  openHorizonDownload: (which) => ipcRenderer.invoke('horizon-open-download', which),

  loginWithMicrosoft: () => ipcRenderer.invoke('auth-microsoft'),
  loginCracked: (username) => ipcRenderer.invoke('auth-cracked', username),
  logout: () => ipcRenderer.invoke('auth-logout'),
  sessionGet: () => ipcRenderer.invoke('session-get'),
  sessionRestore: (username) => ipcRenderer.invoke('session-restore', username),
  getSkinTexture: (username) => ipcRenderer.invoke('get-skin-texture', username),

  getSettings: () => ipcRenderer.invoke('settings-get'),
  setSettings: (patch) => ipcRenderer.invoke('settings-set', patch),
  getSkins: () => ipcRenderer.invoke('skins-get'),
  saveSkins: (data) => ipcRenderer.invoke('skins-save', data),
  getCosmetics: (payload) => ipcRenderer.invoke('cosmetics-get', payload),
  saveCosmetics: (payload) => ipcRenderer.invoke('cosmetics-set', payload),
  openDataFolder: (which) => ipcRenderer.invoke('settings-open-folder', which),
  pickJava: () => ipcRenderer.invoke('settings-pick-java'),
  javaInfo: () => ipcRenderer.invoke('settings-java-info'),
  fetchContent: () => ipcRenderer.invoke('content-fetch'),
  serversStatus: (ips) => ipcRenderer.invoke('servers-status', ips),
  banStatus: (payload) => ipcRenderer.invoke('ban-status', payload),
  pendingBan: () => ipcRenderer.invoke('ban-pending'),

  appVersion: () => ipcRenderer.invoke('app-version'),
  getUpdateState: () => ipcRenderer.invoke('update-state'),
  checkUpdate: () => ipcRenderer.invoke('update-check'),
  downloadUpdate: () => ipcRenderer.invoke('update-download'),
  installUpdate: () => ipcRenderer.invoke('update-install'),

  listProfiles: () => ipcRenderer.invoke('profiles-list'),
  setActiveProfile: (id) => ipcRenderer.invoke('profiles-set-active', id),
  createProfile: (patch) => ipcRenderer.invoke('profiles-create', patch),
  updateProfile: (payload) => ipcRenderer.invoke('profiles-update', payload),
  deleteProfile: (id) => ipcRenderer.invoke('profiles-delete', id),
  openProfileFolder: (id) => ipcRenderer.invoke('profiles-open-folder', id),
  remoteVersions: () => ipcRenderer.invoke('profiles-versions'),
  minecraftScan: (root) => ipcRenderer.invoke('minecraft-scan', root),
  minecraftPick: () => ipcRenderer.invoke('minecraft-pick'),
  minecraftImport: (payload) => ipcRenderer.invoke('minecraft-import', payload),

  launchProfile: (payload) => ipcRenderer.invoke('launch-profile', payload),
  stopGame: (profileId) => ipcRenderer.invoke('stop-game', profileId),
  getGameState: () => ipcRenderer.invoke('game-state'),
  listInstances: () => ipcRenderer.invoke('instances-list'),

  searchModrinth: (payload) => ipcRenderer.invoke('modrinth-search', payload),
  installMod: (payload) => ipcRenderer.invoke('mod-install', payload),
  listMods: (payload) => ipcRenderer.invoke('mods-list', payload),
  setModEnabled: (payload) => ipcRenderer.invoke('mod-set-enabled', payload),
  removeMod: (payload) => ipcRenderer.invoke('mod-remove', payload),
  openModsFolder: (payload) => ipcRenderer.invoke('mods-open-folder', payload),

  searchModpacks: (payload) => ipcRenderer.invoke('modpacks-search', payload),
  listModpacks: () => ipcRenderer.invoke('modpacks-installed'),
  installModpack: (payload) => ipcRenderer.invoke('modpack-install', payload),

  // Shaders
  listShaders: (payload) => ipcRenderer.invoke('shaders-list', payload),
  installShader: (payload) => ipcRenderer.invoke('shaders-install', payload),
  removeShader: (payload) => ipcRenderer.invoke('shaders-remove', payload),
  setActiveShader: (payload) => ipcRenderer.invoke('shaders-set-active', payload),
  openShadersFolder: (payload) => ipcRenderer.invoke('shaders-open-folder', payload),
  searchShaderpacks: (payload) => ipcRenderer.invoke('shaderpacks-search', payload),

  // Resource Packs
  listResourcepacks: (payload) => ipcRenderer.invoke('resourcepacks-list', payload),
  installResourcepack: (payload) => ipcRenderer.invoke('resourcepacks-install', payload),
  removeResourcepack: (payload) => ipcRenderer.invoke('resourcepacks-remove', payload),
  setActiveResourcepacks: (payload) => ipcRenderer.invoke('resourcepacks-set-active', payload),
  openResourcepacksFolder: (payload) => ipcRenderer.invoke('resourcepacks-open-folder', payload),
  searchResourcepacks: (payload) => ipcRenderer.invoke('resourcepacks-search', payload),

  // Friends
  syncFriends: (payload) => ipcRenderer.invoke('friends-sync', payload),
  lookupFriend: (payload) => ipcRenderer.invoke('friends-lookup', payload),
  sendFriendRequest: (payload) => ipcRenderer.invoke('friends-request', payload),
  acceptFriendRequest: (payload) => ipcRenderer.invoke('friends-accept', payload),
  declineFriendRequest: (payload) => ipcRenderer.invoke('friends-decline', payload),
  removeFriend: (payload) => ipcRenderer.invoke('friends-remove', payload),
  sendGameInvite: (payload) => ipcRenderer.invoke('friends-invite', payload),
  joinWorld: (payload) => ipcRenderer.invoke('friends-join', payload),
  sendChatMessage: (payload) => ipcRenderer.invoke('friends-chat-send', payload),
  getChatHistory: (payload) => ipcRenderer.invoke('friends-chat-history', payload),
  getOnlinePlayers: () => ipcRenderer.invoke('friends-online'),

  // Store wallet / daily rewards
  getDailyReward: (payload) => ipcRenderer.invoke('store-daily-status', payload),
  claimDailyReward: (payload) => ipcRenderer.invoke('store-daily-claim', payload),
  getWallet: (payload) => ipcRenderer.invoke('store-wallet', payload),

  onBanDetected: (callback) => on('ban-detected', callback),
  onLaunchProgress: (callback) => on('launch-progress', callback),
  onGameState: (callback) => on('game-state', callback),
  onInstancesChanged: (callback) => on('instances-changed', callback),
  onOpenInstances: (callback) => on('open-instances', callback),
  onGameExit: (callback) => on('game-exit', callback),
  onGameLog: (callback) => on('game-log', callback),
  onModpackProgress: (callback) => on('modpack-progress', callback),
  onProfilesChanged: (callback) => on('profiles-changed', callback),
  onProfileSetup: (callback) => on('profile-setup', callback),
  onUpdateState: (callback) => on('update-state', callback),
  onMaximized: (callback) => on('window-maximized', callback)
});
