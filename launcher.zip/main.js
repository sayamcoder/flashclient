const { app, BrowserWindow, ipcMain, shell, Menu, dialog, Tray, Notification, nativeImage } = require('electron');
const path = require('path');
const { pathToFileURL } = require('url');
const ejs = require('ejs');
const fs = require('fs');
const https = require('https');

/* Fix Electron disk cache access denied on Windows. Use a writable cache
   directory under userData and cap its size so the launcher never hits
   “Access is denied (0x5)” when moving cache files. */
app.commandLine.appendSwitch('disk-cache-dir', path.join(app.getPath('userData'), 'cache'));
app.commandLine.appendSwitch('disk-cache-size', '52428800'); /* 50 MB */
app.commandLine.appendSwitch('disable-http-cache', 'false');

/* Ignore SSL certificate errors so external HTTPS endpoints (Microsoft auth,
   Mojang, Google Fonts) don’t crash the renderer with net_error -101 when the
   network resets the TLS handshake. */
app.commandLine.appendSwitch('ignore-certificate-errors', 'true');
app.commandLine.appendSwitch('disable-features', 'SSLErrorPage');

const settingsStore = require('./lib/config');
const sessionStore = require('./lib/session');
const profiles = require('./lib/profiles');
const importer = require('./lib/import');
const mods = require('./lib/mods');
const modpack = require('./lib/modpack');
const performance = require('./lib/performance');
const { DiscordRpc } = require('./lib/discord');
const minecraft = require('./lib/minecraft');
const { launchGame, offlineUuid } = require('./lib/launch');
const { findInstalled: findJavaRuntimes } = require('./lib/java');
const content = require('./lib/content');
const serverStatus = require('./lib/server-status');
const launcherManifest = require('./lib/launcher-manifest');
const cosmeticsStore = require('./lib/cosmetics');
const horizon = require('./lib/horizon');
const clientMod = require('./lib/client-mod');
const updater = require('./lib/updater');
const shaders = require('./lib/shaders');
const friends = require('./lib/friends');
const storeApi = require('./lib/store');

Menu.setApplicationMenu(null);

/* Everything the launcher writes (profiles, downloaded game files, Java,
   settings) lives under one folder. Older builds used the package name. */
app.setName('flash-client');

function migrateLegacyData() {
  const target = app.getPath('userData');
  const legacy = path.join(app.getPath('appData'), 'perigee-launcher');
  if (path.resolve(legacy) === path.resolve(target) || !fs.existsSync(legacy)) return;

  fs.mkdirSync(target, { recursive: true });
  for (const entry of fs.readdirSync(legacy)) {
    const from = path.join(legacy, entry);
    const to = path.join(target, entry);
    if (fs.existsSync(to)) continue;
    try {
      fs.renameSync(from, to);
    } catch (err) {
      try { fs.cpSync(from, to, { recursive: true }); } catch (copyErr) { /* best effort */ }
    }
  }
}

migrateLegacyData();

let mainWindow;

/* Tray / background state. Declared up here because the window's close
   handler reads them, and createWindow runs before the tray section below. */
let tray = null;
let isQuitting = false;
/* One notification per app run. Repeating it on every close turns into noise
   the player learns to ignore. */
let trayHintShown = false;

const sslBypassAgent = new https.Agent({
  rejectUnauthorized: false,
  keepAlive: true
});

const discord = new DiscordRpc();

let microsoftAccount = null;
let localAccount = null;

/* ---------- game sessions ----------
   One entry per running Minecraft. The launcher used to hold a single
   gameHandle + gameState pair, which made a second launch impossible. Every
   session now owns its own handle, start time and last progress patch, and the
   old single-game reading is derived from the collection so nothing else in
   this file has to know how many games are open.

   Keyed by profile id on purpose: two copies of the same profile would share a
   game folder, save files and mods folder, so that pair is refused while a
   different profile is free to run alongside. */
const sessions = new Map();

/* Where a launch is in its setup phase, before there is a process to track.
   `launching` covers Java/loader/library/asset downloads, which take minutes
   the first time and should not read as "nothing is happening". */
const launchesInFlight = new Set();

/* Set when a startup ban check fires before the interface is listening. */
let pendingBan = null;

function currentAccount() {
  return microsoftAccount || localAccount;
}

/* ---------- session helpers ---------- */

function sessionPayload(session) {
  if (!session) return null;
  return {
    profileId: session.profileId,
    name: session.name,
    gameVersion: session.gameVersion,
    loader: session.loader,
    phase: session.phase,
    startedAt: session.startedAt,
    pid: session.handle?.process?.pid || null,
    server: session.server || null,
    exitCode: session.exitCode ?? null,
    error: session.error || null
  };
}

function activeSessions() {
  return [...sessions.values()];
}

function runningSessions() {
  return activeSessions().filter((s) => s.phase === 'running');
}

/* Everything the renderer and the Discord presence need, in one shape. The
   flat `phase`/`profileId` fields keep older call sites working: they describe
   the newest session, which is what a single-game launcher used to show. */
function gameStatePayload() {
  const all = activeSessions().sort((a, b) => a.startedAt - b.startedAt);
  const newest = all[all.length - 1] || null;
  let phase = 'idle';
  if (newest) phase = newest.phase;

  return {
    phase,
    profileId: newest?.profileId || null,
    launchedAt: newest?.startedAt || 0,
    count: all.length,
    runningCount: all.filter((s) => s.phase === 'running').length,
    sessions: all.map(sessionPayload)
  };
}

function broadcastSessions() {
  const state = gameStatePayload();
  send('game-state', state);
  send('instances-changed', state);
  updateTray();
  return state;
}

/* The launch that owns this event. Looked up by id rather than by comparing
   profile fields, because a session can exit while a replacement is starting. */
function sessionFor(profileId) {
  return sessions.get(profileId) || null;
}

function registerSession(session) {
  sessions.set(session.profileId, session);
  return session;
}

function dropSession(profileId) {
  const session = sessions.get(profileId);
  if (!session) return null;
  sessions.delete(profileId);
  return session;
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1040,
    height: 640,
    minWidth: 1040,
    minHeight: 640,
    resizable: true,
    maximizable: true,
    frame: false,
    backgroundColor: '#09090b',
    show: false,
    center: true,
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  const templatePath = path.join(__dirname, 'src', 'views', 'index.ejs');
  const outputPath = path.join(app.getPath('userData'), 'index.html');
  const outputDir = path.dirname(outputPath);
  const assetBaseUrl = pathToFileURL(`${path.join(__dirname, 'src', 'public')}${path.sep}`).href;

  ejs.renderFile(templatePath, { version: app.getVersion(), appName: 'Flash Client' }, (err, str) => {
    if (err) {
      console.error('EJS Compile Error:', err);
      return;
    }

    try {
      fs.mkdirSync(outputDir, { recursive: true });
      fs.writeFileSync(outputPath, str.replace('<head>', `<head>\n  <base href="${assetBaseUrl}">`));
    } catch (writeErr) {
      console.error('Generated HTML write failed:', writeErr);
      return;
    }

    mainWindow.loadFile(outputPath);
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    syncPresence();
  });

  mainWindow.on('maximize', broadcastMaximized);
  mainWindow.on('unmaximize', broadcastMaximized);
  mainWindow.on('enter-full-screen', broadcastMaximized);
  mainWindow.on('leave-full-screen', broadcastMaximized);
  mainWindow.webContents.on('did-finish-load', broadcastMaximized);

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  /* A window with a game behind it is only hidden. The tray entry is how it
     comes back, so the player is never left hunting in the taskbar for a
     launcher that looks gone. */
  mainWindow.on('close', (event) => {
    if (isQuitting) return;
    if (!sessions.size) return;
    if (settingsStore.settings().runInBackground === false) return;
    event.preventDefault();
    hideToTray();
  });
}

function send(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
}

/* ---------- presence ---------- */

function syncPresence() {
  const settings = settingsStore.settings();
  discord.setEnabled(settings.discordRpc);
  if (!settings.discordRpc) return;

  const running = runningSessions();
  const starting = activeSessions().filter((s) => s.phase === 'launching');
  /* With several games open the newest one is what the player just started, so
     that is the one Discord should show. */
  const focus = [...running, ...starting].sort((a, b) => b.startedAt - a.startedAt)[0] || null;
  const profile = profiles.active();
  const more = running.length > 1 ? ` +${running.length - 1} more` : '';

  let activity;
  if (focus) {
    const since = { start: focus.startedAt };
    activity = running.length
      ? { details: 'Playing Minecraft', state: `${focus.name}${more}`, timestamps: since }
      : { details: 'Starting Minecraft', state: `${focus.name}${more}`, timestamps: since };
  } else {
    activity = { details: 'In the launcher', state: profile.name };
  }

  discord.setActivity(activity);
}

/* ---------- window controls ---------- */

ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-close', () => mainWindow?.close());

ipcMain.handle('window-maximize', () => {
  if (!mainWindow || mainWindow.isDestroyed()) return false;
  if (mainWindow.isMaximized() || mainWindow.isFullScreen()) {
    if (mainWindow.isFullScreen()) mainWindow.setFullScreen(false);
    else mainWindow.unmaximize();
  } else {
    mainWindow.maximize();
  }
  /* maximize()/unmaximize() resolve on the next native frame on Windows, so
     isMaximized() would still report the *old* state here. Report the state we
     just asked for; the maximize/unmaximize events correct it afterwards. */
  return mainWindow.isMaximized() || mainWindow.isFullScreen();
});

ipcMain.handle('window-maximized-state', () => Boolean(mainWindow && !mainWindow.isDestroyed() && (mainWindow.isMaximized() || mainWindow.isFullScreen())));

/* The title bar's X hides to the tray while a game is open; the tray menu and
   this handler are the only ways back out, so both have to exist. */
ipcMain.on('window-hide', () => hideToTray());
ipcMain.on('tray-show', () => showWindow());
ipcMain.handle('app-quit', () => { isQuitting = true; app.quit(); });
ipcMain.handle('tray-available', () => Boolean(ensureTray()));

/* Point the custom title bar at the real window state. Without this the
   restore/maximize glyph can drift whenever the OS changes the window
   (snap, double-click, Aero shake, work-area change). */
function broadcastMaximized() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  send('window-maximized', Boolean(mainWindow.isMaximized() || mainWindow.isFullScreen()));
}

/* ---------- tray, background running, notifications */

function trayImage() {
  const icon = nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png'));
  return icon.isEmpty() ? nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.ico')) : icon;
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
    return;
  }
  if (mainWindow.isMinimized()) mainWindow.restore();
  if (!mainWindow.isVisible()) mainWindow.show();
  mainWindow.focus();
}

function hideToTray() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  ensureTray();
  mainWindow.hide();

  if (trayHintShown || !Notification.isSupported()) return;
  trayHintShown = true;
  new Notification({
    title: 'Flash Client is still running',
    body: sessions.size
      ? `Minecraft keeps playing in the background. Reopen Flash Client from the tray icon.`
      : 'Reopen Flash Client from the tray icon. Quit from its menu to close it.',
    icon: trayImage()
  }).show();
}

function ensureTray() {
  if (tray) return tray;

  try {
    tray = new Tray(trayImage());
  } catch (err) {
    /* A session without a usable icon (some remote desktop shells) still has
       to be able to close the launcher, so a missing tray only costs the
       tray. */
    launcherLog(`tray unavailable: ${err.message}`);
    return null;
  }

  tray.on('click', showWindow);
  tray.on('double-click', showWindow);
  updateTray();
  return tray;
}

function updateTray() {
  if (!tray) return;
  const running = runningSessions().length;
  const total = sessions.size;

  tray.setToolTip(
    total
      ? `Flash Client — ${total} instance${total === 1 ? '' : 's'}${running ? ' running' : ' starting'}`
      : 'Flash Client'
  );
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: total ? `Flash Client — ${total} running` : 'Flash Client', enabled: false },
    { type: 'separator' },
    { label: 'Open Flash Client', click: showWindow },
    { label: 'Instances…', click: () => { showWindow(); send('open-instances'); } },
    {
      label: 'Stop all instances',
      enabled: total > 0,
      click: () => { for (const s of sessions.values()) s.handle?.stop(); }
    },
    { type: 'separator' },
    { label: 'Quit Flash Client', click: () => { isQuitting = true; app.quit(); } }
  ]));
}

function destroyTray() {
  tray?.destroy();
  tray = null;
}

/* The first time a game survives the launcher being closed, say so out loud:
   otherwise "Flash Client is still running" looks like a stuck process. */
function notifyGameRunning(session) {
  if (!Notification.isSupported()) return;
  if (settingsStore.settings().backgroundNotice === false) return;
  new Notification({
    title: 'Flash Client is running in the background',
    body: `${session.name} is open. Closing this window keeps it running — use the tray icon to come back.`,
    icon: trayImage()
  }).show();
}

/* After the last game closes the launcher is just a tray icon the player may
   have forgotten about, so it mentions that the window is still there. */
function maybeNotifyAllClosed() {
  if (sessions.size || !tray || !mainWindow || mainWindow.isVisible()) return;
  if (!Notification.isSupported()) return;
  new Notification({
    title: 'Minecraft closed',
    body: 'Flash Client is still open in the tray.',
    icon: trayImage()
  }).show();
}

/* ---------- skins ---------- */

function downloadImageBuffer(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { agent: sslBypassAgent, headers: { 'User-Agent': 'MinecraftLauncher/1.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadImageBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      const data = [];
      res.on('data', chunk => data.push(chunk));
      res.on('end', () => resolve(Buffer.concat(data)));
    }).on('error', reject);
  });
}

ipcMain.handle('get-skin-texture', async (event, username) => {
  if (!username || username.trim().length < 3) return null;
  const cleanName = encodeURIComponent(username.trim());
  const sources = [
    `https://minotar.net/skin/${cleanName}`,
    `https://mc-heads.net/skin/${cleanName}`
  ];

  for (const url of sources) {
    try {
      const buffer = await downloadImageBuffer(url);
      if (buffer.length) return `data:image/png;base64,${buffer.toString('base64')}`;
    } catch (err) {
      // try the next mirror
    }
  }
  return null;
});

/* ---------- accounts ---------- */

ipcMain.handle('auth-cracked', async (event, username) => {
  const name = String(username || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) {
    return { success: false, message: 'Use 3-16 letters, numbers or underscores.' };
  }

  localAccount = {
    username: name,
    uuid: offlineUuid(name),
    accessToken: '0',
    type: 'cracked'
  };
  sessionStore.save(localAccount);
  microsoftAccount = null;
  syncLauncherManifest();
  return { success: true, username: name, type: 'cracked' };
});

const MINECRAFT_CLIENT_ID = '00000000402b5328';
const REDIRECT_URI = 'https://login.live.com/oauth20_desktop.srf';
const SCOPE = 'service::user.auth.xboxlive.com::MBI_SSL';

ipcMain.handle('auth-microsoft', async () => {
  return new Promise((resolve) => {
    const authUrl = `https://login.live.com/oauth20_authorize.srf?client_id=${MINECRAFT_CLIENT_ID}&response_type=code&scope=${encodeURIComponent(SCOPE)}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}`;

    const authWindow = new BrowserWindow({
      width: 520,
      height: 680,
      parent: mainWindow,
      modal: true,
      title: 'Sign in to Minecraft',
      autoHideMenuBar: true,
      backgroundColor: '#1b1b1f',
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true
      }
    });

    authWindow.webContents.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36');

    let handled = false;

    async function handleRedirect(newUrl) {
      if (handled) return;
      if (newUrl.startsWith(REDIRECT_URI)) {
        handled = true;
        authWindow.close();

        const urlObj = new URL(newUrl);
        const code = urlObj.searchParams.get('code');
        const error = urlObj.searchParams.get('error');

        if (error || !code) {
          resolve({ success: false, message: error || 'Login cancelled by user' });
          return;
        }

        try {
          const msTokenRes = await fetch('https://login.live.com/oauth20_token.srf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
              client_id: MINECRAFT_CLIENT_ID,
              code: code,
              grant_type: 'authorization_code',
              redirect_uri: REDIRECT_URI,
              scope: SCOPE
            })
          });
          const msTokenData = await msTokenRes.json();

          const xblRes = await fetch('https://user.auth.xboxlive.com/user/authenticate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({
              Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: msTokenData.access_token },
              RelyingParty: 'http://auth.xboxlive.com',
              TokenType: 'JWT'
            })
          });
          const xblData = await xblRes.json();

          const xstsRes = await fetch('https://xsts.auth.xboxlive.com/xsts/authorize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({
              Properties: { SandboxId: 'RETAIL', UserTokens: [xblData.Token] },
              RelyingParty: 'rp://api.minecraftservices.com/',
              TokenType: 'JWT'
            })
          });
          const xstsData = await xstsRes.json();

          const mcLoginRes = await fetch('https://api.minecraftservices.com/authentication/login_with_xbox', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ identityToken: `XBL3.0 x=${xblData.DisplayClaims.xui[0].uhs};${xstsData.Token}` })
          });
          const mcLoginData = await mcLoginRes.json();

          const profileRes = await fetch('https://api.minecraftservices.com/minecraft/profile', {
            headers: { 'Authorization': `Bearer ${mcLoginData.access_token}` }
          });

          if (profileRes.status === 404) {
            resolve({ success: false, message: 'This Microsoft account does not own Minecraft Java Edition.' });
            return;
          }

          const profileData = await profileRes.json();
          microsoftAccount = {
            username: profileData.name,
            uuid: profileData.id,
            accessToken: mcLoginData.access_token,
            type: 'microsoft',
            skin: await microsoftSkin(profileData.id)
          };
          localAccount = null;
          sessionStore.clear();
          syncLauncherManifest();
          resolve({ success: true, username: profileData.name, uuid: profileData.id, type: 'microsoft' });
        } catch (err) {
          resolve({ success: false, message: err.message });
        }
      }
    }

    authWindow.webContents.on('will-navigate', (e, url) => handleRedirect(url));
    authWindow.webContents.on('will-redirect', (e, url) => handleRedirect(url));

    authWindow.on('closed', () => {
      if (!handled) {
        resolve({ success: false, message: 'Login cancelled by user' });
      }
    });

    authWindow.loadURL(authUrl);
  });
});

ipcMain.handle('auth-logout', () => {
  microsoftAccount = null;
  localAccount = null;
  sessionStore.clear();
  for (const profile of profiles.list()) {
    try {
      launcherManifest.remove(profiles.gameDir(profile.id));
    } catch (err) {
      /* a locked folder should not block signing out */
    }
  }
  return { success: true };
});

ipcMain.handle('session-get', () => {
  const account = currentAccount();
  if (!account) return null;
  return { username: account.username, uuid: account.uuid, type: account.type };
});

/* The interface remembers the last offline name in localStorage; this puts the
   main process back on the same account so Play keeps working after a restart. */
ipcMain.handle('session-restore', (event, username) => {
  const existing = currentAccount();
  if (existing) return { success: true, username: existing.username, type: existing.type };

  const name = String(username || '').trim();
  if (!/^[a-zA-Z0-9_]{3,16}$/.test(name)) return { success: false };

  localAccount = {
    username: name,
    uuid: offlineUuid(name),
    accessToken: '0',
    type: 'cracked'
  };
  sessionStore.save(localAccount);
  syncLauncherManifest();
  return { success: true, username: name, type: 'cracked' };
});

/* ---------- skins ---------- */

function skinsFile() {
  return path.join(app.getPath('userData'), 'skins.json');
}

function readSkinsState() {
  try {
    const saved = JSON.parse(fs.readFileSync(skinsFile(), 'utf8'));
    return {
      skins: Array.isArray(saved?.skins) ? saved.skins : [],
      selectedId: typeof saved?.selectedId === 'string' ? saved.selectedId : null
    };
  } catch (err) {
    return { skins: [], selectedId: null };
  }
}

/* The client build renders skins from the launcher manifest, so a Microsoft
   account's own skin has to come through here as well — the game does not fetch
   it for offline-style launches and the player stayed on the default skin. */
async function microsoftSkin(uuid) {
  const id = String(uuid || '').replace(/-/g, '');
  if (!id) return null;
  try {
    const res = await fetch(`https://sessionserver.mojang.com/session/minecraft/profile/${id}`, {
      headers: { 'User-Agent': 'FlashClient/1.0.4 (Minecraft launcher)' },
      signal: AbortSignal.timeout(8000)
    });
    if (!res.ok) return null;
    const data = await res.json();
    const prop = (data.properties || []).find((entry) => entry.name === 'textures');
    if (!prop) return null;
    const decoded = JSON.parse(Buffer.from(prop.value, 'base64').toString('utf8'));
    const texture = decoded?.textures?.SKIN;
    if (!texture?.url) return null;

    const type = texture.metadata?.model === 'slim' ? 'slim' : 'wide';
    const remote = texture.url.replace(/^http:\/\//i, 'https://');

    // Cracked profiles are delivered as a PNG the launcher writes locally, so
    // the premium skin takes the exact same route instead of relying on the
    // client build to fetch a remote texture by itself.
    try {
      const bytes = await downloadImageBuffer(remote);
      const size = launcherManifest.pngSize(bytes);
      if (size && size.width === 64 && size.height && size.height <= 64) {
        return { skinUrl: `data:image/png;base64,${bytes.toString('base64')}`, type };
      }
    } catch (err) {
      /* fall back to the hosted texture */
    }

    return { skinUrl: remote, type };
  } catch (err) {
    return null;
  }
}

/* Offline accounts always need the file because no skin server sits behind the
   name. A Microsoft account uses its own Mojang texture unless the user picked
   an uploaded one. */
function syncLauncherManifest(profileId) {
  const account = currentAccount();
  if (!account) return { success: false };

  const profile = profiles.list().find((p) => p.id === profileId) || profiles.active();
  const gameDir = profiles.gameDir(profile.id);
  const saved = readSkinsState();
  const picked = saved.skins.find((entry) => entry.id === saved.selectedId) || null;

  let skin = picked;
  if (account.type === 'microsoft' && picked?.custom !== true) {
    skin = account.skin?.skinUrl ? { skinUrl: account.skin.skinUrl, type: account.skin.type } : null;
  }

  try {
    if (!skin) {
      launcherManifest.remove(gameDir);
      return { success: true, removed: true };
    }
    return { success: true, ...launcherManifest.write({ gameDir, username: account.username, skin }) };
  } catch (err) {
    console.error('[flashclient] launcher manifest:', err.message);
    return { success: false, message: err.message };
  }
}

ipcMain.handle('skins-get', () => readSkinsState());

/* ---------- cosmetics ---------- */

ipcMain.handle('cosmetics-get', (event, payload) => {
  const profileId = payload?.profileId || profiles.active().id;
  const account = currentAccount();
  return cosmeticsStore.state(profileId, account?.uuid);
});

ipcMain.handle('cosmetics-set', (event, payload) => {
  const profileId = payload?.profileId || profiles.active().id;
  return cosmeticsStore.select(profileId, payload?.selection || {});
});

ipcMain.handle('skins-save', (event, data) => {
  const skins = Array.isArray(data?.skins) ? data.skins : [];
  const selectedId = typeof data?.selectedId === 'string' ? data.selectedId : null;
  fs.mkdirSync(path.dirname(skinsFile()), { recursive: true });
  fs.writeFileSync(skinsFile(), JSON.stringify({ skins, selectedId }, null, 2));
  syncLauncherManifest();
  return { success: true };
});

/* ---------- settings ---------- */

ipcMain.handle('settings-get', () => settingsStore.settings());

ipcMain.handle('settings-set', async (event, patch) => {
  const next = settingsStore.update(patch || {});
  syncPresence();
  if (patch?.autoUpdate === true) {
    scheduleUpdateChecks();
    checkForUpdate(true);
  }
  return next;
});

ipcMain.handle('settings-open-folder', async (event, which) => {
  const target = which === 'data'
    ? minecraft.dataDirs().data
    : app.getPath('userData');
  fs.mkdirSync(target, { recursive: true });
  const error = await shell.openPath(target);
  return { success: !error, message: error, path: target };
});

ipcMain.handle('settings-pick-java', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Pick java.exe',
    properties: ['openFile'],
    filters: [{ name: 'Java', extensions: ['exe'] }]
  });
  if (result.canceled || !result.filePaths.length) return { success: false };
  return { success: true, path: result.filePaths[0] };
});

/* ---------- Horizon (Minecraft Rust Edition) ---------- */

/* Async on purpose: the registry scan is the only probe that can take a
   moment, and doing it on the main thread would jank the window. */
ipcMain.handle('horizon-status', () => horizon.statusAsync(settingsStore.settings().horizonPath));

/* Where the player installs Horizon from. Only official pages, and the
   renderer never gets to pass a URL in. */
ipcMain.handle('horizon-open-download', async (event, which) => {
  const target = which === 'releases' ? horizon.DETAILS.releases : horizon.DETAILS.install;
  try {
    await shell.openExternal(target);
    return { success: true, url: target };
  } catch (err) {
    return { success: false, message: `Could not open your browser: ${err.message}` };
  }
});

/* The guided hand-off. Returns the steps and requirements so the renderer can
   show them, and re-detects in case the player installed Horizon a moment ago
   with this dialog still open. */
ipcMain.handle('horizon-bootstrap', async () => {
  const found = await horizon.statusAsync(settingsStore.settings().horizonPath);
  if (found.found) return { success: true, installed: true, ...found };
  return { success: true, installed: false, ...horizon.bootstrapInfo() };
});

ipcMain.handle('horizon-pick', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Pick horizon-launcher.exe',
    properties: ['openFile'],
    filters: [{ name: 'Horizon launcher', extensions: ['exe'] }]
  });
  if (result.canceled || !result.filePaths.length) return { success: false, canceled: true };
  settingsStore.update({ horizonPath: result.filePaths[0] });
  return { success: true, ...horizon.statusAsync(result.filePaths[0]) };
});

ipcMain.handle('horizon-pick-installer', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select the Horizon installer',
    properties: ['openFile'],
    filters: [{ name: 'Horizon installer', extensions: ['exe'] }]
  });
  if (result.canceled || !result.filePaths.length) return { success: false, canceled: true };
  return { success: true, path: result.filePaths[0] };
});

ipcMain.handle('horizon-install', (event, installerPath) => {
  return horizon.install({ exe: installerPath });
});

ipcMain.handle('horizon-launch', async () => {
  const settings = settingsStore.settings();
  /* Rust Edition is meant to start the game, not open Horizon's own window.
     `direct: true` means `horizon-launcher play`. The `horizonDirect` setting
     is left in place for backwards compatibility but is no longer consulted. */
  const result = horizon.launch({ exe: settings.horizonPath, direct: true });
  /* The player may have installed Horizon since the last detection pass, so
     re-check through the registry before telling them it is missing. */
  if (!result.success && result.found === false) {
    const late = await horizon.statusAsync(settings.horizonPath);
    if (late.found) {
      settingsStore.update({ horizonPath: late.path });
      return horizon.launch({ exe: late.path, direct: true });
    }
  }
  return result;
});

ipcMain.handle('settings-java-info', async () => {
  const settings = settingsStore.settings();
  try {
    const runtimes = await findJavaRuntimes(minecraft.dataDirs().data, settings.javaPath);
    return {
      success: true,
      runtimes: runtimes.map((r) => ({ path: r.path, version: r.version, major: r.major })),
      managed: minecraft.dataDirs().runtimes
    };
  } catch (err) {
    console.error('Java scan failed:', err);
    return { success: false, runtimes: [] };
  }
});

ipcMain.handle('content-fetch', () => content.fetchContent());

/* ---------- Ban enforcement ---------- */

const http = require('http');

function banStatus({ uuid, name, ip }) {
  return new Promise((resolve) => {
    const base = content.configuredUrl() || 'http://localhost:3000';
    const url = new URL(`${base}/api/ban/status`);
    if (uuid) url.searchParams.set('uuid', uuid);
    if (name) url.searchParams.set('name', name);
    if (ip) url.searchParams.set('ip', ip);
    const client = url.protocol === 'https:' ? https : http;
    const req = client.get(url, { timeout: 8000 }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(body)); } catch (err) { resolve({ ok: false, banned: false, error: 'Invalid ban response.' }); }
      });
    });
    req.on('error', () => resolve({ ok: false, banned: false, error: 'Could not reach ban service.' }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, banned: false, error: 'Ban check timed out.' }); });
  });
}

ipcMain.handle('ban-status', async (event, payload) => {
  const { uuid, name, ip } = payload || {};
  return banStatus({ uuid, name, ip });
});

/* The startup ban check can finish before the renderer has subscribed to
   `ban-detected`. The interface drains it here instead of losing it. */
ipcMain.handle('ban-pending', () => {
  const ban = pendingBan;
  pendingBan = null;
  return ban;
});

ipcMain.handle('servers-status', async (event, ips) => {
  try {
    return { success: true, statuses: await serverStatus.statuses(ips) };
  } catch (err) {
    return { success: false, statuses: {}, error: String(err?.message || 'Status lookup failed.') };
  }
});

/* ---------- launcher updates ---------- */

let updateManifest = null;
let updateState = {
  phase: 'idle',
  current: app.getVersion(),
  latest: '',
  notes: [],
  size: 0,
  publishedAt: '',
  mandatory: false,
  progress: null,
  message: '',
  checkedAt: 0
};

function updatePayload() {
  return { ...updateState };
}

function setUpdate(patch) {
  updateState = { ...updateState, ...patch };
  send('update-state', updatePayload());
  return updatePayload();
}

async function checkForUpdate(autoDownload = false) {
  if (updateState.phase === 'checking' || updateState.phase === 'downloading') {
    return updatePayload();
  }

  // The updater swaps a Windows setup .exe, so macOS and Linux builds update
  // by hand instead of downloading an installer they cannot run.
  if (process.platform !== 'win32') {
    return setUpdate({
      phase: 'unconfigured',
      checkedAt: Date.now(),
      message: 'This macOS/Linux build installs updates by hand. Download the newest build from the GitHub releases page.'
    });
  }

  setUpdate({ phase: 'checking', message: '', progress: null });
  const result = await updater.check(app.getVersion());
  const checkedAt = Date.now();

  if (!result.success) {
    if (result.reason === 'not-configured') {
      return setUpdate({
        phase: 'unconfigured',
        checkedAt,
        message: 'This build has no update feed, so it cannot check for new versions.'
      });
    }
    if (result.reason === 'bad-manifest') {
      return setUpdate({
        phase: 'error',
        checkedAt,
        message: 'The update feed is missing something: it needs a version, a secure installer link and its checksum. On GitHub the release tag is the version and the setup .exe needs a sha256 digest.'
      });
    }
    if (result.reason === 'offline') {
      return setUpdate({
        phase: 'error',
        checkedAt,
        message: 'Could not reach the update server. Check this PC’s connection and try again.'
      });
    }
    const limited = /returned 403/.test(result.message || '');
    return setUpdate({
      phase: 'error',
      checkedAt,
      message: limited
        ? 'GitHub is limiting update checks from this network right now. Try again in a few minutes.'
        : (result.message || 'Could not reach the update server.')
    });
  }

  if (!result.available) {
    updateManifest = null;
    return setUpdate({
      phase: 'current',
      latest: result.manifest.version,
      notes: [],
      size: 0,
      publishedAt: '',
      mandatory: false,
      progress: null,
      message: '',
      checkedAt
    });
  }

  updateManifest = result.manifest;
  const recovered = updater.recover(result.manifest);
  setUpdate({
    phase: recovered ? 'ready' : 'available',
    latest: result.manifest.version,
    notes: result.manifest.notes,
    size: result.manifest.size,
    publishedAt: result.manifest.publishedAt,
    mandatory: result.manifest.mandatory,
    progress: null,
    message: '',
    checkedAt
  });

  if (autoDownload && !recovered) startUpdateDownload();
  return updatePayload();
}

async function startUpdateDownload() {
  if (!updateManifest) return updatePayload();
  if (updateState.phase === 'downloading') return updatePayload();
  if (updateState.phase === 'ready' && updateState.latest === updateManifest.version) return updatePayload();

  const manifest = updateManifest;
  setUpdate({ phase: 'downloading', message: '', progress: { received: 0, total: manifest.size, percent: 0 } });

  try {
    await updater.download(manifest, {
      onProgress: (progress) => setUpdate({ progress })
    });
    return setUpdate({ phase: 'ready', progress: null, message: '' });
  } catch (err) {
    return setUpdate({ phase: 'available', progress: null, message: err.message });
  }
}

ipcMain.handle('app-version', () => app.getVersion());
ipcMain.handle('update-state', () => updatePayload());
ipcMain.handle('update-check', () => checkForUpdate(false));
ipcMain.handle('update-download', () => startUpdateDownload());

ipcMain.handle('update-install', async () => {
  // The installer replaces the launcher's own files, so it waits for Minecraft.
  if (sessions.size) {
    return {
      success: false,
      message: `Close ${sessions.size === 1 ? 'Minecraft' : 'all Minecraft instances'} before updating the launcher.`,
      gameRunning: true
    };
  }

  // A download finished in an earlier session is still on disk; adopt it so the
  // button keeps working after the launcher is reopened.
  if (updateManifest) updater.recover(updateManifest);

  const result = await updater.install();
  if (!result.success) return result;

  setUpdate({ phase: 'installing', message: '' });
  setTimeout(() => app.quit(), 400);
  return { success: true };
});

/* ---------- profiles ---------- */

function countMods(profileId) {
  try {
    return fs.readdirSync(profiles.modsDir(profileId)).filter((f) => /\.jar(\.disabled)?$/i.test(f)).length;
  } catch (err) {
    return 0;
  }
}

function isReady(profile) {
  if (typeof profile === 'string') profile = profiles.list().find((p) => p.id === profile);
  if (!profile) return false;

  // An imported profile already has its files in the folder it came from.
  if (profile.minecraftDir) {
    const source = profile.sourceVersion || profile.gameVersion;
    return fs.existsSync(path.join(profiles.runtimeDir(profile.id), 'versions', source, `${source}.json`))
      || fs.existsSync(path.join(profiles.instanceDir(profile.id), '.ready.json'));
  }
  return fs.existsSync(path.join(profiles.instanceDir(profile.id), '.ready.json'));
}

/* java.exe lives in <data>/runtimes/jre-<major>/<jdk>/bin/, so the folder to
   remove is the one right under runtimes/. Anything outside our runtimes
   folder (system Java) is left alone. */
function removeRuntimeFolder(javaPath) {
  if (typeof javaPath !== 'string') return;
  const marker = `${path.sep}runtimes${path.sep}`;
  const at = javaPath.toLowerCase().lastIndexOf(marker);
  if (at < 0) return;
  const root = javaPath.slice(0, at + marker.length - 1);
  const name = javaPath.slice(at + marker.length).split(path.sep)[0];
  if (!name) return;
  fs.rmSync(path.join(root, name), { recursive: true, force: true });
}

function profileSummary(profile) {
  return {
    ...profile,
    mods: countMods(profile.id),
    ready: isReady(profile)
  };
}

ipcMain.handle('profiles-list', () => ({
  profiles: profiles.list().map(profileSummary),
  activeId: profiles.active().id
}));

ipcMain.handle('profiles-active', () => profileSummary(profiles.active()));

ipcMain.handle('profiles-set-active', (event, id) => {
  const profile = profiles.setActive(id);
  syncPresence();
  syncLauncherManifest(profile.id);
  send('profiles-changed', { activeId: profile.id });
  return { success: true, profile: profileSummary(profile) };
});

ipcMain.handle('profiles-create', (event, patch) => {
  const created = profiles.create(patch || {});
  fs.mkdirSync(profiles.modsDir(created.id), { recursive: true });
  const settings = settingsStore.settings();
  if (settings.performanceMods !== false && created.loader !== 'vanilla' && !created.minecraftDir) {
    setupPerformanceMods(created);
  }
  return { success: true, profile: profileSummary(created) };
});

async function setupPerformanceMods(profile) {
  send('profile-setup', { profileId: profile.id, phase: 'start', loader: profile.loader, gameVersion: profile.gameVersion });
  try {
    const installed = await performance.installFor(profile, (patch) => {
      send('profile-setup', { profileId: profile.id, phase: 'perf', loader: profile.loader, gameVersion: profile.gameVersion, ...patch });
    });
    send('profile-setup', { profileId: profile.id, phase: 'done', installed, count: countMods(profile.id) });
  } catch (err) {
    send('profile-setup', { profileId: profile.id, phase: 'error', message: err.message });
  }
}

ipcMain.handle('profiles-update', (event, payload) => {
  const { id, ...patch } = payload || {};
  const updated = profiles.update(id, patch);
  if (!updated) return { success: false, message: 'Unknown profile.' };
  if (updated.id === profiles.active().id) syncPresence();
  return { success: true, profile: profileSummary(updated) };
});

ipcMain.handle('profiles-delete', (event, id) => {
  const result = profiles.remove(id);
  return result.success
    ? { success: true, activeId: result.active.id }
    : { success: false, message: result.message };
});

ipcMain.handle('profiles-open-folder', async (event, id) => {
  const dir = profiles.gameDir(id);
  fs.mkdirSync(dir, { recursive: true });
  const error = await shell.openPath(dir);
  return { success: !error, message: error };
});

ipcMain.handle('profiles-versions', async () => {
  try {
    return { success: true, versions: await minecraft.minecraftVersions() };
  } catch (err) {
    return { success: false, message: 'Could not reach Mojang.' };
  }
});

/* ---------- importing an existing .minecraft ---------- */

ipcMain.handle('minecraft-scan', (event, root) => {
  if (root !== undefined && (typeof root !== 'string' || !path.isAbsolute(root) || !fs.existsSync(root))) {
    return { success: false, message: 'That folder does not exist.', root: '', versions: [] };
  }
  const result = importer.scan(root);
  if (!result.success) return result;

  const imported = new Set(profiles.list().map((p) => p.sourceVersion).filter(Boolean));
  return {
    ...result,
    versions: result.versions.map((version) => ({ ...version, imported: imported.has(version.id) }))
  };
});

ipcMain.handle('minecraft-pick', async () => {
  const picked = await dialog.showOpenDialog(mainWindow, {
    title: 'Pick a .minecraft folder',
    properties: ['openDirectory']
  });
  if (picked.canceled || !picked.filePaths[0]) return { success: false };
  return { success: true, path: picked.filePaths[0] };
});

ipcMain.handle('minecraft-import', (event, payload) => {
  const { root, versions } = payload || {};
  if (typeof root !== 'string' || !path.isAbsolute(root)) {
    return { success: false, message: 'Unknown Minecraft folder.' };
  }
  if (!Array.isArray(versions) || !versions.length) {
    return { success: false, message: 'Pick at least one version.' };
  }

  const scanned = importer.scan(root);
  if (!scanned.success) return scanned;

  const gameDir = scanned.game || scanned.root;
  const runtimeDir = scanned.runtime && scanned.runtime !== gameDir ? scanned.runtime : '';

  const wanted = new Set(versions);
  const created = [];
  for (const version of scanned.versions) {
    if (!wanted.has(version.id) || !version.supported) continue;
    if (profiles.list().some((p) => p.sourceVersion === version.id)) continue;

    // A game folder is named by the player, so that name reads better than the
    // loader id it happens to launch with.
    let name = scanned.mode === 'game' ? path.basename(gameDir) : version.id;
    if (profiles.list().some((p) => p.name === name)) name = `${name} ${version.loader}`;

    const profile = profiles.create({
      name,
      gameVersion: version.gameVersion,
      loader: version.loader,
      loaderVersion: version.loaderVersion,
      minecraftDir: gameDir,
      runtimeDir,
      sourceVersion: version.id
    });
    fs.mkdirSync(profiles.modsDir(profile.id), { recursive: true });
    created.push(profileSummary(profile));
  }

  return { success: true, profiles: created, root: gameDir, runtime: runtimeDir || gameDir };
});

/* ---------- launch ---------- */

/* Installed builds run without a console, so jar/network failures need to land
   in a file the player can send us. */
function launcherLog(line) {
  try {
    const dir = path.join(app.getPath('userData'), 'logs');
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, 'launcher.log'), `${new Date().toISOString()} ${line}\n`);
  } catch (err) {
    /* logging must never break a launch */
  }
}

ipcMain.handle('launch-profile', async (event, payload) => {
  const profileId = typeof payload === 'string' ? payload : payload?.profileId;
  const server = typeof payload === 'object' ? payload?.server || null : null;

  const account = currentAccount();
  if (!account) return { success: false, message: 'Sign in before launching.' };
  if (!/^[A-Za-z0-9_]{3,16}$/.test(account.username)) {
    return { success: false, message: 'Sign in again with a name of 3-16 letters, numbers or underscores.' };
  }

  const profile = profiles.list().find((p) => p.id === profileId) || profiles.active();
  const settings = settingsStore.settings();

  /* Two copies of one profile would share a game folder, a level save and a
     mods folder, and Minecraft locks its session file — so that pair is
     refused while other profiles are free to start alongside. */
  if (sessions.has(profile.id)) {
    return { success: false, message: `${profile.name} is already running.`, profileId: profile.id };
  }
  if (launchesInFlight.has(profile.id)) {
    return { success: false, message: `${profile.name} is already starting.`, profileId: profile.id };
  }

  launchesInFlight.add(profile.id);

  // The manifest must match --username, so both are written for this profile.
  // A skin lookup that failed at sign-in gets one more try here.
  if (account.type === 'microsoft' && !account.skin) {
    account.skin = await microsoftSkin(account.uuid);
    if (!account.skin) console.error('[flashclient] Microsoft skin lookup failed; using the default skin.');
  }
  syncLauncherManifest(profile.id);
  const modsDir = profiles.modsDir(profile.id);
  const modInstall = clientMod.install(profile.gameVersion, modsDir);

  // A jar already in mods/ states which Fabric it needs; read it now so the
  // loader is chosen before the game starts instead of crashing on it.
  let minFabricLoader = clientMod.fabricRequirement(path.join(modsDir, clientMod.FILE_NAME));
  if (!minFabricLoader) minFabricLoader = (await modInstall).fabricLoader || null;

  const session = registerSession({
    profileId: profile.id,
    name: profile.name,
    gameVersion: profile.gameVersion,
    loader: profile.loader,
    phase: 'launching',
    startedAt: Date.now(),
    handle: null,
    server,
    exitCode: null,
    error: null,
    progress: null
  });

  broadcastSessions();
  syncPresence();

  /* Progress is per session now, so the renderer tags the overlay it belongs
     to. The 120 ms throttle is shared across sessions — a player launching two
     builds at once should not be flooded by either. */
  let lastSent = 0;
  const report = (patch) => {
    session.progress = { ...session.progress, ...patch };
    const now = Date.now();
    if (patch.phase !== 'assets' && patch.phase !== 'libraries' && now - lastSent < 80) return;
    if (now - lastSent < 120) return;
    lastSent = now;
    send('launch-progress', { profileId: profile.id, ...patch });
  };

  /* Ends a session from either path — spawn failure or a real exit — so the
     bookkeeping lives in one place. Only this session is removed; its
     neighbours keep running. */
  const finishSession = (info) => {
    const removed = dropSession(profile.id);
    launchesInFlight.delete(profile.id);
    if (!removed) return;
    if (info) {
      removed.exitCode = info.code ?? null;
      removed.error = info.error || null;
    }
    send('game-exit', { profileId: profile.id, name: profile.name, ...(info || {}) });
    broadcastSessions();
    syncPresence();
    maybeNotifyAllClosed();
  };

  try {
    const buildSpec = async () => {
      const prepared = await minecraft.prepareProfile(
        { ...profile, javaPath: profile.javaPath || '' },
        settings,
        report,
        { minFabricLoader }
      );
      return { ...prepared, gameDir: profiles.gameDir(profile.id) };
    };

    let spec = await buildSpec();

    // No build for this version is normal; the game still starts.
    const modResult = await modInstall;
    if (!modResult.installed && modResult.reason !== 'not-configured') {
      const note = `FlashClient mod not installed (${modResult.reason}) for ${profile.gameVersion}`;
      launcherLog(note);
      send('game-log', { profileId: profile.id, line: `[launcher] ${note}` });
    }

    const startGame = (prepared) => launchGame({
      spec: prepared,
      account,
      ram: profile.ram || settings.defaultRam || 4,
      server,
      onLog: (line) => send('game-log', { profileId: profile.id, line }),
      /* A session the player already stopped must not come back to life here;
         `stop()` kills the child, which lands in this same handler. */
      onExit: (info) => finishSession(info)
    });

    let handle = startGame(spec);
    try {
      await handle.ready;
    } catch (err) {
      // A runtime the launcher downloaded itself can be half-unpacked or
      // swallowed by antivirus; throw it away and fetch a clean copy once
      // instead of making the player work out what "spawn Unknown" means.
      const brokenRuntime = spec.java?.source === 'downloaded'
        && ['UNKNOWN', 'ENOENT', 'EINVAL'].includes(err.code);
      if (!brokenRuntime) throw err;

      removeRuntimeFolder(spec.java.path);
      report({ phase: 'java', message: 'Java did not start. Downloading it again…', done: 0, total: 1, ratio: 0 });
      spec = await buildSpec();
      handle = startGame(spec);
      await handle.ready;
    }

    // Imported profiles launch from their own folder, so the instance folder
    // may not exist yet; the marker is per profile and belongs there.
    fs.mkdirSync(profiles.instanceDir(profile.id), { recursive: true });
    fs.writeFileSync(
      path.join(profiles.instanceDir(profile.id), '.ready.json'),
      JSON.stringify({
        versionId: spec.versionId,
        loader: profile.loader,
        java: spec.java.path,
        javaMajor: spec.java.major,
        at: Date.now()
      }, null, 2)
    );

    session.handle = handle;
    session.phase = 'running';
    launchesInFlight.delete(profile.id);
    broadcastSessions();
    syncPresence();
    notifyGameRunning(session);

    if (settings.minimizeOnLaunch) mainWindow?.minimize();

    return { success: true, profileId: profile.id, versionId: spec.versionId, java: spec.java.version, clientMod: modResult };
  } catch (err) {
    finishSession({ code: null, error: err.message });
    return { success: false, message: err.message, profileId: profile.id };
  }
});

/* Stop one instance, or every instance when no profile is named. */
ipcMain.handle('stop-game', (event, payload) => {
  const profileId = typeof payload === 'string' ? payload : payload?.profileId;
  const targets = profileId
    ? [sessions.get(profileId)].filter(Boolean)
    : runningSessions();

  if (!targets.length) {
    return { success: false, message: profileId ? 'That instance is not running.' : 'Minecraft is not running.' };
  }

  for (const session of targets) session.handle?.stop();
  return { success: true, stopped: targets.map((s) => s.profileId) };
});

ipcMain.handle('game-state', () => gameStatePayload());
ipcMain.handle('instances-list', () => gameStatePayload());

/* ---------- Modrinth + mods ---------- */

ipcMain.handle('modrinth-search', async (event, payload) => {
  const { query = '', gameVersion, loader, limit = 30 } = payload || {};
  if (!gameVersion || !loader) return { success: false, message: 'Pick a profile first.' };

  const facets = [['project_type:mod'], [`versions:${gameVersion}`]];
  if (loader !== 'vanilla') facets.push([`categories:${loader}`]);

  const params = new URLSearchParams({
    query,
    limit: String(Math.min(Math.max(limit, 1), 40)),
    index: query ? 'relevance' : 'downloads',
    facets: JSON.stringify(facets)
  });

  try {
    const data = await mods.request(`/search?${params}`);
    return {
      success: true,
      total: data.total_hits || 0,
      mods: (data.hits || []).map((hit) => ({
        id: hit.project_id,
        slug: hit.slug,
        title: hit.title,
        description: hit.description,
        author: hit.author,
        downloads: hit.downloads,
        icon: hit.icon_url
      }))
    };
  } catch (err) {
    return { success: false, message: 'Could not reach Modrinth.' };
  }
});

ipcMain.handle('mod-install', async (event, payload) => {
  const { projectId, profileId, gameVersion, loader, icon, title } = payload || {};
  if (!projectId || !gameVersion) return { success: false, message: 'Missing install details.' };
  try {
    const mod = await mods.install(profileId, { projectId, gameVersion, loader, icon, title });
    return { success: true, mod };
  } catch (err) {
    return { success: false, message: err.message };
  }
});

ipcMain.handle('mods-list', async (event, payload) => {
  const { profileId } = payload || {};
  if (!profileId) return [];
  return mods.list(profileId);
});

ipcMain.handle('mod-set-enabled', async (event, payload) => {
  const { profileId, filename, enabled } = payload || {};
  return mods.setEnabled(profileId, filename, Boolean(enabled));
});

ipcMain.handle('mod-remove', async (event, payload) => {
  const { profileId, filename } = payload || {};
  return mods.remove(profileId, filename);
});

ipcMain.handle('mods-open-folder', async (event, payload) => {
  const { profileId, gameVersion } = payload || {};
  const dir = profiles.modsDir(profileId || gameVersion);
  fs.mkdirSync(dir, { recursive: true });
  const error = await shell.openPath(dir);
  return { success: !error, message: error };
});

/* ---------- modpacks ---------- */

ipcMain.handle('modpacks-search', async (event, payload) => {
  const { query = '', gameVersion, loader, limit = 30 } = payload || {};
  try {
    const data = await modpack.search({ query, gameVersion, loader, limit });
    return { success: true, ...data };
  } catch (err) {
    return { success: false, message: err.message === 'Pick a profile first.' ? err.message : 'Could not reach Modrinth.' };
  }
});

ipcMain.handle('modpacks-installed', () => modpack.installedProjects());

ipcMain.handle('modpack-install', async (event, payload) => {
  const { projectId, versionId, gameVersion, loader, ram } = payload || {};
  const settings = settingsStore.settings();
  let lastSent = 0;

  try {
    const result = await modpack.install({
      projectId,
      versionId,
      gameVersion,
      loader,
      ram: ram || settings.defaultRam || 4,
      onProgress: (progress) => {
        const now = Date.now();
        if (progress.phase === 'files' && progress.done !== progress.total && now - lastSent < 120) return;
        lastSent = now;
        event.sender.send('modpack-progress', { projectId, ...progress });
      }
    });
    return { success: true, ...result };
  } catch (err) {
    launcherLog(`modpack install failed (${projectId}): ${err.message}`);
    return { success: false, message: err.message };
  }
});

/* ---------- Shaders & Resource Packs ---------- */

ipcMain.handle('shaders-list', async (event, payload) => {
  const { profileId } = payload || {};
  if (!profileId) return [];
  return shaders.listShaderpacks(profileId);
});

ipcMain.handle('shaders-install', async (event, payload) => {
  const { profileId, projectId, gameVersion, loader } = payload || {};
  if (!profileId || !projectId || !gameVersion || !loader) return { success: false, message: 'Missing install details.' };
  try {
    const result = await shaders.installShaderpackFromModrinth(profileId, projectId, gameVersion, loader);
    return { success: true, ...result };
  } catch (err) {
    return { success: false, message: err.message };
  }
});

ipcMain.handle('shaders-remove', async (event, payload) => {
  const { profileId, filename } = payload || {};
  if (!profileId || !filename) return { success: false, message: 'Missing details.' };
  return shaders.removeShaderpack(profileId, filename);
});

ipcMain.handle('shaders-set-active', async (event, payload) => {
  const { profileId, filename } = payload || {};
  if (!profileId) return { success: false, message: 'Missing details.' };
  return shaders.setActiveShaderpack(profileId, filename || null);
});

ipcMain.handle('shaders-open-folder', async (event, payload) => {
  const { profileId } = payload || {};
  const dir = shaders.shaderpacksDir(profileId);
  fs.mkdirSync(dir, { recursive: true });
  const error = await shell.openPath(dir);
  return { success: !error, message: error };
});

ipcMain.handle('shaderpacks-search', async (event, payload) => {
  const { query = '', gameVersion, loader, limit = 20 } = payload || {};
  if (!gameVersion || !loader) return { success: false, message: 'Pick a profile first.' };
  return shaders.searchShaderpacks(query, gameVersion, loader);
});

ipcMain.handle('resourcepacks-list', async (event, payload) => {
  const { profileId } = payload || {};
  if (!profileId) return [];
  return shaders.listResourcepacks(profileId);
});

ipcMain.handle('resourcepacks-install', async (event, payload) => {
  const { profileId, projectId, gameVersion, loader } = payload || {};
  if (!profileId || !projectId || !gameVersion || !loader) return { success: false, message: 'Missing install details.' };
  try {
    const result = await shaders.installResourcepackFromModrinth(profileId, projectId, gameVersion, loader);
    return { success: true, ...result };
  } catch (err) {
    return { success: false, message: err.message };
  }
});

ipcMain.handle('resourcepacks-remove', async (event, payload) => {
  const { profileId, filename } = payload || {};
  if (!profileId || !filename) return { success: false, message: 'Missing details.' };
  return shaders.removeResourcepack(profileId, filename);
});

ipcMain.handle('resourcepacks-set-active', async (event, payload) => {
  const { profileId, filenames } = payload || {};
  if (!profileId || !Array.isArray(filenames)) return { success: false, message: 'Missing details.' };
  return shaders.setActiveResourcepacks(profileId, filenames);
});

ipcMain.handle('resourcepacks-open-folder', async (event, payload) => {
  const { profileId } = payload || {};
  const dir = shaders.resourcepacksDir(profileId);
  fs.mkdirSync(dir, { recursive: true });
  const error = await shell.openPath(dir);
  return { success: !error, message: error };
});

ipcMain.handle('resourcepacks-search', async (event, payload) => {
  const { query = '', gameVersion, loader, limit = 20 } = payload || {};
  if (!gameVersion || !loader) return { success: false, message: 'Pick a profile first.' };
  return shaders.searchResourcepacks(query, gameVersion, loader);
});

/* ---------- Friends ---------- */

ipcMain.handle('friends-sync', async (event, payload) => {
  const { uuid, name } = payload || {};
  if (!uuid || !name) return { ok: false, error: 'Missing account info.' };
  return friends.syncFriends(uuid, name);
});

ipcMain.handle('friends-lookup', async (event, payload) => {
  const { name } = payload || {};
  if (!name) return { ok: false, error: 'Missing name.' };
  return friends.lookupFriend(name);
});

ipcMain.handle('friends-request', async (event, payload) => {
  const { uuid, name, targetUuid, targetName } = payload || {};
  if (!uuid || !name || !targetUuid || !targetName) return { ok: false, error: 'Missing details.' };
  return friends.sendFriendRequest(uuid, name, targetUuid, targetName);
});

ipcMain.handle('friends-accept', async (event, payload) => {
  const { uuid, name, targetUuid } = payload || {};
  if (!uuid || !name || !targetUuid) return { ok: false, error: 'Missing details.' };
  return friends.acceptFriendRequest(uuid, name, targetUuid);
});

ipcMain.handle('friends-decline', async (event, payload) => {
  const { uuid, name, targetUuid } = payload || {};
  if (!uuid || !name || !targetUuid) return { ok: false, error: 'Missing details.' };
  return friends.declineFriendRequest(uuid, name, targetUuid);
});

ipcMain.handle('friends-remove', async (event, payload) => {
  const { uuid, name, targetUuid } = payload || {};
  if (!uuid || !name || !targetUuid) return { ok: false, error: 'Missing details.' };
  return friends.removeFriend(uuid, name, targetUuid);
});

ipcMain.handle('friends-invite', async (event, payload) => {
  const { code, uuid, name, targetUuid } = payload || {};
  if (!code || !uuid || !name || !targetUuid) return { ok: false, error: 'Missing details.' };
  return friends.sendGameInvite(code, uuid, name, targetUuid);
});

ipcMain.handle('friends-join', async (event, payload) => {
  const { code, uuid, name } = payload || {};
  if (!code || !uuid || !name) return { ok: false, error: 'Missing details.' };
  return friends.joinWorld(code, uuid, name);
});

ipcMain.handle('friends-chat-send', async (event, payload) => {
  const { uuid, name, targetUuid, text } = payload || {};
  if (!uuid || !name || !targetUuid || !text) return { ok: false, error: 'Missing details.' };
  return friends.sendChatMessage(uuid, name, targetUuid, text);
});

ipcMain.handle('friends-chat-history', async (event, payload) => {
  const { uuid, peerUuid, since } = payload || {};
  if (!uuid || !peerUuid) return { ok: false, error: 'Missing details.' };
  return friends.getChatHistory(uuid, peerUuid, since);
});

ipcMain.handle('friends-online', async () => {
  return friends.getOnlinePlayers();
});

/* ---------- Store wallet + daily rewards ---------- */

ipcMain.handle('store-daily-status', async (event, payload) => {
  const { uuid } = payload || {};
  if (!uuid) return { ok: false, error: 'Missing account info.' };
  return storeApi.getDailyStatus(uuid);
});

ipcMain.handle('store-daily-claim', async (event, payload) => {
  const { uuid } = payload || {};
  if (!uuid) return { ok: false, error: 'Missing account info.' };
  return storeApi.claimDaily(uuid);
});

ipcMain.handle('store-wallet', async (event, payload) => {
  const { uuid } = payload || {};
  if (!uuid) return { ok: false, error: 'Missing account info.' };
  return storeApi.getWallet(uuid);
});

/* The release feed is polled while the launcher stays open, so a build published
   mid-session is downloaded without anyone opening the update page. */
const UPDATE_RECHECK_MS = 30 * 60 * 1000;
let updateTimer = null;

function scheduleUpdateChecks() {
  if (updateTimer) return;
  updateTimer = setInterval(() => {
    if (settingsStore.settings().autoUpdate === false) return;
    checkForUpdate(true);
  }, UPDATE_RECHECK_MS);
}

app.whenReady().then(async () => {
  localAccount = sessionStore.load();
  createWindow();
  syncPresence();

  /* Built up front so the close handler never has to create it mid-shutdown,
     and so the icon is already sitting in the tray by the time a game starts. */
  ensureTray();

  /* Check ban status on startup so a banned account can’t proceed past the login screen.
     The renderer is still loading this early, so an event sent now would be lost —
     queue it and let the renderer ask for it once it is listening. */
  if (localAccount) {
    try {
      const ban = await banStatus({
        uuid: localAccount.uuid,
        name: localAccount.username
      });
      if (ban?.banned) {
        pendingBan = ban;
        send('ban-detected', ban);
      }
    } catch (err) {
      /* Ban check failure must not block launcher startup. */
    }
  }

  if (settingsStore.settings().autoUpdate !== false) {
    setTimeout(() => { checkForUpdate(true); }, 1500);
    scheduleUpdateChecks();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

/* Closing the launcher while a game runs hides it instead of ending the
   process tree, so a stray click on X never costs the player their world.
   Nothing is shown on screen — the tray icon is the signal that the launcher
   is still there. */
app.on('before-quit', () => {
  isQuitting = true;
  discord.disconnect();
  for (const session of sessions.values()) {
    if (session.handle?.isRunning()) session.handle.stop();
  }
  destroyTray();
});
