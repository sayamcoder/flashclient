/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/views/**/*.ejs', './src/public/**/*.js'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
        mono: ['"DM Mono"', 'ui-monospace', 'monospace']
      },
      colors: {
        canvas: '#09090b',
        panel: '#0e0e12',
        subtle: '#14141a',
        borderSubtle: '#22222b',
        accentPurple: {
          400: '#c084fc',
          500: '#a855f7',
          600: '#9333ea',
          glow: 'rgba(192, 132, 252, 0.35)'
        }
      },
      boxShadow: {
        'glow-purple': '0 0 35px -5px rgba(168, 85, 247, 0.45)',
        'glow-lantern': '0 0 25px 8px rgba(217, 70, 239, 0.3)'
      }
    }
  },
  plugins: []
};